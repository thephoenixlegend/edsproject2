# Hypervisors & Virtual Machines — An Interactive Guide

A single-page, scroll-driven interactive website that explains how hypervisors and virtual machines work, built with plain HTML/CSS/JS and [GSAP](https://gsap.com/) ScrollTrigger.

## Run locally

No build step needed. Just open `index.html` in a browser (an internet connection is needed to load GSAP from the cdnjs CDN).

```bash
# or serve it locally
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Tech

- HTML, CSS, vanilla JavaScript
- GSAP 3.12.5 + ScrollTrigger (via cdnjs)

## Live demo

Enable GitHub Pages (Settings → Pages → Deploy from branch → `main` / root) and the site will be available at
`https://<your-username>.github.io/hypervisors-interactive-guide/`.

## Author

Sudarshan Chakraborty
